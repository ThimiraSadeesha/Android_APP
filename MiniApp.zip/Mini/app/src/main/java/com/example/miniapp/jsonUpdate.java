package com.example.miniapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class jsonUpdate extends AppCompatActivity {

    private TextView nextDeliveryNameTextView;
    private TextView updateDateTextView;
    private Button btndownload;
    private DbHelper dHelper;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json_update);

        dHelper = new DbHelper(this);
        btndownload = findViewById(R.id.btndownload);
        updateDateTextView = findViewById(R.id.first);
        nextDeliveryNameTextView = findViewById(R.id.secnd);

        btndownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new FetchJSONTask().execute("http://10.0.2.2/json/Subs_list.json");
            }
        });
    }

    private class FetchJSONTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String url = urls[0];
            String result = "";

            try {
                URL urlObject = new URL(url);
                HttpURLConnection connection = (HttpURLConnection) urlObject.openConnection();
                connection.connect();

                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }

                result = stringBuilder.toString();

                reader.close();
                inputStream.close();
                connection.disconnect();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }

        @SuppressLint("SetTextI18n")
        @Override
        protected void onPostExecute(String result) {
            try {
                JSONArray jsonArray = new JSONArray(result);
                if (jsonArray.length() > 0) {
                    // Clear existing data in the table
                    dHelper.clearSubscriberTable();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);

                        int subscriber_id = jsonObject.getInt("sub_id");
                        String name = jsonObject.getString("Fullname");
                        String city = jsonObject.getString("city");
                        String address = jsonObject.getString("address");
                        String phone = jsonObject.getString("phone");
                        double latitude = jsonObject.getDouble("latitude");
                        double longitude = jsonObject.getDouble("longitude");
                        String deliveryStatus = jsonObject.optString("delivery_status");
                        String subscriptionEndDate = jsonObject.optString("subs_end_date" );
                        String newspaper = jsonObject.optString("newspaper");
                        String subscriptionMode = jsonObject.optString("subscription_type");

                        dHelper.insertSubscriber(subscriber_id, name, city, address, phone, latitude,
                                longitude, deliveryStatus, subscriptionEndDate, newspaper, subscriptionMode);
                    }
                    btndownload.setCompoundDrawables(null, null, null, null);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    String currentDate = sdf.format(new Date());

                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

            Toast.makeText(jsonUpdate.this, "Successfully Updated Server and Map", Toast.LENGTH_SHORT).show();
        }
    }
}