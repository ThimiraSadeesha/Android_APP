package com.example.miniapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class alertbox extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alertbox);
    }
}