package com.example.miniapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText txtId, txtPassword;
    private Button btnClear, btnLogin;
    private TextView txtResult;
    private DataBaseHelper databaseHelper;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtId = findViewById(R.id.txtid);
        txtPassword = findViewById(R.id.txtpassword);
        btnClear = findViewById(R.id.btnclear);
        btnLogin = findViewById(R.id.btnlogin);
        txtResult = findViewById(R.id.txtresult);
        databaseHelper = new DataBaseHelper(this);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String id = txtId.getText().toString();
                String password = txtPassword.getText().toString();

                if (validateLogin(id, password)) {

                    Intent intent = new Intent(MainActivity.this, DashBoard.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid login credentials!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                txtId.setText("");
                txtPassword.setText("");
            }
        });
    }
        private boolean validateLogin(String id, String password) {
            SQLiteDatabase db = databaseHelper.getReadableDatabase();
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            Cursor cursor = db.rawQuery(query, new String[]{id, password});
            boolean isValid = cursor.getCount() > 0;
            cursor.close();
            db.close();
            return isValid;
        }


}