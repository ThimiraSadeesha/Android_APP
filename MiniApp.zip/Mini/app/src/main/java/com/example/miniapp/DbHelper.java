package com.example.miniapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.List;
import java.util.concurrent.Flow;

public class DbHelper extends SQLiteOpenHelper {

    public static final String DBName = "RouteDB.db";
    public static final int Db_version = 1;

    // Subscriber table
    public static final String Table_SubcriberTB = "subscriberTB";
    public static final String Sub_ID = "sub_id";
    public static final String Sub_name = "Fullname";
    public static final String Subs_City = "city";
    public static final String Sub_address = "address";
    public static final String Sub_mobile = "phone";
    public static final String Sub_Lattitude = "latitude";
    public static final String Sub_Longitude = "longitude";
    public static final String Delivery_status = "delivery_status";
    public static final String newspaper_model = "newspaper";
    public static final String Subs_end_Day = "subs_end_date";
    public static final String subscription_type = "subscription_type";

    public DbHelper( Context context ) {
        super(context, DBName, null, Db_version);
    }
    @Override
    public void onCreate(SQLiteDatabase mydb) {
        String createSubTableQuery = "CREATE TABLE " + Table_SubcriberTB + " (" +
                Sub_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                Sub_name + " TEXT, " +
                Subs_City + " TEXT, " +
                Sub_address + " TEXT, " +
                Sub_mobile + " TEXT, " +
                Sub_Lattitude + " REAL, " +
                Sub_Longitude + " REAL, " +
                Delivery_status + " TEXT, " +
                Subs_end_Day + " TEXT, " +
                newspaper_model + " TEXT, " +
                subscription_type + " TEXT)";
          mydb.execSQL(createSubTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase mydb, int i, int i1) {
        mydb.execSQL("DROP TABLE IF EXISTS " + Table_SubcriberTB);
        onCreate(mydb);
    }
    public void clearSubscriberTable() {
        SQLiteDatabase Mydb = getWritableDatabase();
        Mydb.delete(Table_SubcriberTB, null, null);
        Mydb.close();
    }
    public void insertSubscriber(int sub_id, String Fullname, String city, String address, String phone,
                                 double latitude, double longitude, String delivery_status,
                                 String subs_end_date, String newspaper, String subscription_type) {
        SQLiteDatabase Mydb = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(Sub_ID, sub_id);
        values.put(Sub_name, Fullname);
        values.put(Subs_City, city);
        values.put(Sub_address, address);
        values.put(Sub_mobile, phone);
        values.put(Sub_Lattitude, latitude);
        values.put(Sub_Longitude, longitude);
        values.put(Delivery_status, delivery_status);
        values.put(Subs_end_Day, subs_end_date);
        values.put(newspaper_model, newspaper);
        values.put(DbHelper.subscription_type, subscription_type);

        Mydb.insert(Table_SubcriberTB, null, values);
        Mydb.close();
    }

    public List<Flow.Subscriber> getAllSubscribers() {

        return null;
    }

}
