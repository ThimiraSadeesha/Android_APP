package com.example.miniapp;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private MapView mapView;
    private GoogleMap googleMap;
    private PopupWindow popupWindow;
    FusedLocationProviderClient fls;
    private DbHelper dbHelper;
    Button closebtn;
    Button  deliverd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        mapView = findViewById(R.id.mapView);
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);
        dbHelper = new DbHelper(this);
        new FetchJSONTask().execute("http://10.0.2.2/json/Subs_list.json");
    }

    @Override
    protected void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onMapReady(@NonNull GoogleMap map) {
        googleMap = map;
        //enable map zoom buttons
        map.getUiSettings().setZoomControlsEnabled(true);
        //set on veiw in srilanka
        LatLng location = new LatLng(6.801748317095831, 79.9226030844503);
        map.moveCamera(CameraUpdateFactory.newLatLng(location));;
        new FetchJSONTask().execute("http://10.0.2.2/json/Subs_list.json");

        SQLiteDatabase mydb = dbHelper.getReadableDatabase();
        Cursor cursor=mydb.query(dbHelper.Table_SubcriberTB, new String[]{dbHelper.Sub_name,dbHelper.Sub_address, dbHelper.Subs_City, dbHelper.Sub_mobile,
                        dbHelper.Sub_Lattitude, dbHelper.Sub_Longitude, dbHelper.Delivery_status, dbHelper.Subs_end_Day, dbHelper.newspaper_model},
                null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                double latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(dbHelper.Sub_Lattitude));
                double longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(dbHelper.Sub_Longitude));
//                String name = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Sub_name));
//                String deliverystatus = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Delivery_status));
//                String phone = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Sub_mobile));
//                String newspaper = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.newspaper_model));
//                String endDate = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Subs_end_Day));
//                String address =cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Sub_address));

                LatLng latLng = new LatLng(latitude, longitude);
                //  BitmapDescriptor icon = BitmapDescriptorFactory.fromResource(R.drawable.location);


                Marker marker = map.addMarker(new MarkerOptions()
                        .position(latLng));
                // .icon(icon));

                assert marker != null;
                //  marker.setTag(new SubscriberDetails(name, address, phone, endDate, newspaper, latitude, longitude));

            } while (cursor.moveToNext());
            cursor.close();
            map.setOnMarkerClickListener(marker -> {
              //  SubscriberDetails subscriberDetails = (SubscriberDetails) marker.getTag();

                if (marker != null) {
                    popupWindow(marker);
                }

                return true;
            });
//            map.setOnMarkerClickListener(marker -> {
//                currentMarker = marker;
//                popupWindow(marker);
//                return true;
//            });

        }



        map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {
                popupWindow(marker);
                return true;
            }
        });

    }

    private class FetchJSONTask extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... urls) {
            String url =urls[0];
            String result="";

            try {
                URL urlObject = new URL(url);
                HttpURLConnection connection =(HttpURLConnection) urlObject.openConnection();
                connection.connect();
                InputStream inputStream=connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder= new StringBuilder();
                String line;
                while ((line=reader.readLine()) !=null){
                    stringBuilder.append(line);
                }
                result=stringBuilder.toString();
                reader.close();
                inputStream.close();
                connection.disconnect();

            } catch (IOException e) {
                e.printStackTrace();
            }
            return result;
        }
        @SuppressLint("SetTextI18n")

        @Override
        protected void onPostExecute(String result) {
            try {

                JSONArray jsonArray = new JSONArray(result);

                for (int i =0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
//                        name = jsonObject.getString("Fullname");
//                         city = jsonObject.getString("city");
                    double latti = jsonObject.getDouble("latitude");
                    double longtt = jsonObject.getDouble("longitude");
                    //Toast.makeText(MapActivity.this, "Name: " + name + ", City: " + city, Toast.LENGTH_SHORT).show();
                    //LatLng location = new LatLng(latti, longtt);
                    // googleMap.addMarker(new MarkerOptions().position(location).title(name));
                    LatLng location = new LatLng(latti, longtt);
//                     .title(name).snippet(city)
                    googleMap.addMarker(new MarkerOptions().position(location));
                }
            }
            catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    //private Marker currentMarker;
    private void popupWindow(Marker marker) {
        SQLiteDatabase mydb = dbHelper.getReadableDatabase();
        Cursor cursor = mydb.query(dbHelper.Table_SubcriberTB, new String[]{
                        dbHelper.Sub_name, dbHelper.Sub_address, dbHelper.Subs_City,
                        dbHelper.Sub_mobile, dbHelper.Sub_Lattitude, dbHelper.Sub_Longitude,
                        dbHelper.Delivery_status, dbHelper.Subs_end_Day, dbHelper.newspaper_model},
                null, null, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            do {
                double latitude = cursor.getDouble(cursor.getColumnIndexOrThrow(dbHelper.Sub_Lattitude));
                double longitude = cursor.getDouble(cursor.getColumnIndexOrThrow(dbHelper.Sub_Longitude));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Sub_name));
                String deliverystatus = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Delivery_status));
                String phone = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Sub_mobile));
                String newspaper = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.newspaper_model));
                String endDate = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Subs_end_Day));
                String address = cursor.getString(cursor.getColumnIndexOrThrow(dbHelper.Sub_address));

                if (latitude == marker.getPosition().latitude && longitude == marker.getPosition().longitude) {
                    View popup = getLayoutInflater().inflate(R.layout.popup_window_layout, null);
                    TextView subname = popup.findViewById(R.id.txtsubname);
                    subname.setText("Subscriber Name: " + name);
                    TextView addressTextView = popup.findViewById(R.id.txtaddress);
                    addressTextView.setText("Address : " + address);
                    TextView newsPaperTextView = popup.findViewById(R.id.txtnewspaper);
                    newsPaperTextView.setText("News Paper : " + newspaper);
                    TextView endDateTextView = popup.findViewById(R.id.txtdate);
                    endDateTextView.setText("Valid Till : " + endDate);
                    TextView mobile = popup.findViewById(R.id.txtmobile);
                    mobile.setText("Mobile : " + phone);
                    TextView delstatus = popup.findViewById(R.id.status);
                    delstatus.setText("Delivery Status : " + deliverystatus);

                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    builder.setView(popup)
                            .setPositiveButton("Close", (dialog, which) -> {
                                dialog.dismiss();
                                cursor.close();
                            })
                            .setNegativeButton("Call", (dialog, which) -> PhoneCall(phone))


                            .setNeutralButton("Directions", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // Open Google Maps for navigation
                                    String destination = latitude + "," + longitude;
                                    Uri gmmIntentUri = Uri.parse("google.navigation:q=" + destination);
                                    Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                                    mapIntent.setPackage("com.google.android.apps.maps");
                                    if (mapIntent.resolveActivity(getPackageManager()) != null) {
                                        startActivity(mapIntent);
                                    } else {
                                        Toast.makeText(MapActivity.this, "Google Maps is not installed", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            })
                            .show();
                    break;
                }
            } while (cursor.moveToNext());

        }

        if (cursor != null) {
            cursor.close();
        }
    }


    private void PhoneCall(String phoneNumber) {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phoneNumber));
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        mapView.onSaveInstanceState(outState);
    }

}
