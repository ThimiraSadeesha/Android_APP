package com.example.miniapp;

import static com.example.miniapp.R.id.successtxt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class DashBoard extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        Button  mapbtn=findViewById(R.id.btnmap);
        Button update=findViewById(R.id.btnUpdate);
        TextView succss=findViewById(R.id.successtxt);
        TextView pending =findViewById(R.id.pendingtxt);
        Button logout =findViewById(R.id.btnlogout);
        TextView greetingText=findViewById(R.id.greetingtxt);


        Button list=findViewById(R.id.btnlist);



        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logoutapp();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentt = new Intent(DashBoard.this,jsonUpdate.class);
                startActivity(intentt);
            }
        });
        list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               succss.setText("9");
                pending.setText("4");

                Toast.makeText(DashBoard.this, "Update Successfully", Toast.LENGTH_SHORT).show();
            }
        });


        mapbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(DashBoard.this,MapActivity.class);
                startActivity(intent);
            }
        });


        //greeting text
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);

        if (hour < 12) {
            greetingText.setText(" Good Morning");
        } else if (hour < 18) {
            greetingText.setText(" Good Afternoon");
        } else {
            greetingText.setText(" Good Evening");
        }

    }
    private void logoutapp(){
        Intent intent = new Intent(DashBoard.this, MainActivity.class);
        startActivity(intent);
        Toast.makeText(this, "Logout Successfully", Toast.LENGTH_SHORT).show();
        finish();
    }




}